.. nicaea documentation master file, created by
   sphinx-quickstart on Sun Feb 19 10:55:09 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

nicaea v2.7 documentation
=========================

Contents:

.. toctree::
   :maxdepth: 4

   nicaea_2.7


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

